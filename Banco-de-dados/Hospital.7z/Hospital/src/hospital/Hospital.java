/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

/**
 *
 * @author SESI_SENAI
 */
public class Hospital {
    
    private int codigo_medico;
    private int id_paciente;

    public int getCodigo_medico() {
        return codigo_medico;
    }

    public void setCodigo_medico(int codigo_medico) {
        this.codigo_medico = codigo_medico;
    }

    public int getId_paciente() {
        return id_paciente;
    }

    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    
}
